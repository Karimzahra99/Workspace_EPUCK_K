#ifndef PI_REGULATOR_H
#define PI_REGULATOR_H


//start the PI regulator thread
void pi_regulator_start(void);

void follow_line_start(void);
#endif /* PI_REGULATOR_H */
